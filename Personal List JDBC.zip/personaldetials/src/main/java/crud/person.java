package crud;

import java.sql.*;
import java.util.*;

public class person{
	
	static final String URL ="jdbc:mysql://localhost:3306/person_det";
    static final String username = "root";
    static final String password = "2578";
	
	public static void main(String[]args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection con = DriverManager.getConnection(URL,username,password);
				     
			Scanner scan = new Scanner(System.in);
			
			while(true) {
				System.out.println("PERSON DETIALS \n"
						+ "1.Add\n"
						+ "2.View\n"
						+ "3.Update\n"
						+ "4.Delete\n"
						+ "5.Exist");
				System.out.print("Enter Choice :");
				int choice = scan.nextInt();
				
				switch(choice) {
				
				case 1:
					System.out.println("Welcome Add Page");
					System.out.print("Name :");
					String name = scan.next();
					System.out.print("Email :");
					String email = scan.next();
					System.out.print("Phone NO :");
					int phoneno = scan.nextInt();
					System.out.print("Address :");
					String address = scan.next();
					
					PreparedStatement ps1 = con.prepareStatement (
							"INSERT INTO detials(name,email,phoneno,address) Values(?,?,?,?)");
					ps1.setString(1,name);
					ps1.setString(2, email);
					ps1.setInt(3, phoneno);
					ps1.setString(4, address);
					
					ps1.executeUpdate();
					
					System.out.println("Inserted.....");
					break;
					
				case 2:
					System.out.println("Person Details");
					Statement st = con.createStatement();
					ResultSet rst = st.executeQuery("SELECT * FROM detials");
					while(rst.next()) {
						System.out.println(rst.getString("name") +" | "+
								rst.getString("email")+" | "+
								rst.getInt("phoneno")+" | "+
								rst.getString("address"));
						
					}
					break;
					
				case 3:
					System.out.println("UPDATE DETIALS");
					System.out.print("Enter ID :");
					int id = scan.nextInt();
					System.out.print("Enter NEW NAME :");
					String newname = scan.next();
					scan.nextLine();
					System.out.print("Enter NEW Mail :");
					String newemail = scan.next();
					System.out.print("Enter NEW PHONE :");
					int newphoneno = scan.nextInt();
					System.out.print("Enter NEW ADDRESS :");
					String newaddress = scan.next();
					PreparedStatement ps2 = con.prepareStatement(
							"UPDATE detials SET name = ?,email = ?,phoneno = ?,address = ? WHERE id = ?");
					ps2.setString(1, newname);
					ps2.setString(2, newemail);
					ps2.setInt(3, newphoneno);
					ps2.setString(4, newaddress);
					ps2.setInt(5, id);
					ps2.executeUpdate();
					System.out.println("Updated");
					break;
					
				case 4:
					System.out.println("DELETED");
					System.out.print("Enter ID :");
					int deleteid = scan.nextInt();
					PreparedStatement ps3 = con.prepareStatement(
							"DELETE FROM detials WHERE id = ?");
					ps3.setInt(1, deleteid);
					ps3.executeUpdate();
					System.out.println("Deleted....");
					break;
					
				case 5:
					System.out.println("Syntax error");
					continue;
				}break;
			}
			}catch(Exception e) {
					System.out.println(e);
				}

	}
	
}